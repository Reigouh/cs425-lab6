-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.7.38-log


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema lab6_fa22_v1
--

CREATE DATABASE IF NOT EXISTS lab6_fa22_v1;
USE lab6_fa22_v1;

--
-- Definition of table `attendee`
--

DROP TABLE IF EXISTS `attendee`;
CREATE TABLE `attendee` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `displayname` varchar(90) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendee`
--

/*!40000 ALTER TABLE `attendee` DISABLE KEYS */;
INSERT INTO `attendee` (`id`,`firstname`,`lastname`,`displayname`) VALUES 
 (1,'Thomas','Beckwith','Thomas Beckwith'),
 (2,'Courtney','Eckhoff','Courtney Eckhoff'),
 (3,'Timothy','Freeman','Timothy Freeman'),
 (4,'Kathy','Cox','Kathy Cox'),
 (5,'Barbara','Freda','Barbara Freda'),
 (6,'Cindy','Leavitt','Cindy Leavitt'),
 (7,'Robert','Holder','Robert Holder'),
 (8,'Ali','Peters','Ali Peters'),
 (9,'Stephanie','Johnson','Stephanie Johnson'),
 (10,'Betty','Hoffmann','Betty Hoffmann'),
 (11,'Robert','Waddell','Robert Waddell'),
 (12,'Shannon','Hartmann','Shannon Hartmann'),
 (13,'James','Jennings','James Jennings'),
 (14,'James','Lipe','James Lipe'),
 (15,'William','Hughes','William Hughes'),
 (16,'Damian','Seymour','Damian Seymour'),
 (17,'Jessica','Meyers','Jessica Meyers'),
 (18,'Florence','Davis','Florence Davis'),
 (19,'Joyce','Herrmann','Joyce Herrmann'),
 (20,'James','Wells','James Wells'),
 (21,'Fred','Madison','Fred Madison'),
 (22,'Mark','Preston','Mark Preston'),
 (23,'Alexander','Hunter','Alexander Hunter'),
 (24,'Dwight','Cepeda','Dwight Cepeda'),
 (25,'Sheryl','Bartholomew','Sheryl Bartholomew'),
 (26,'Jennifer','Connor','Jennifer Connor'),
 (27,'Sheryl','Puckett','Sheryl Puckett'),
 (28,'Willie','Lujan','Willie Lujan'),
 (29,'Alyson','Scott','Alyson Scott'),
 (30,'Daniel','Cooper','Daniel Cooper'),
 (31,'Maurice','McAllister','Maurice McAllister'),
 (32,'Brenda','Kincheloe','Brenda Kincheloe'),
 (33,'Queen','Corey','Queen Corey'),
 (34,'Kim','Huffman','Kim Huffman'),
 (35,'James','Reed','James Reed'),
 (36,'Joshua','Wood','Joshua Wood'),
 (37,'Paul','Amick','Paul Amick'),
 (38,'Crystal','Hill','Crystal Hill'),
 (39,'Bradley','Leboeuf','Bradley Leboeuf'),
 (40,'Nathan','Beil','Nathan Beil'),
 (41,'Matthew','Lupo','Matthew Lupo'),
 (42,'Mavis','Favela','Mavis Favela'),
 (43,'Jose','Le','Jose Le'),
 (44,'Paul','Beeler','Paul Beeler'),
 (45,'Pamela','Haase','Pamela Haase'),
 (46,'Eugene','Wright','Eugene Wright'),
 (47,'George','Chapell','George Chapell'),
 (48,'Kenneth','Terrell','Kenneth Terrell'),
 (49,'Theresa','Gibson','Theresa Gibson'),
 (50,'Amie','Littell','Amie Littell');
/*!40000 ALTER TABLE `attendee` ENABLE KEYS */;


--
-- Definition of table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `username` varchar(45) NOT NULL,
  `password` char(128) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` (`username`,`password`) VALUES 
 ('dbuser','ab698858f43ead86f13416d1eb67b84f264cbe3c3e91529f5ff7a5ba1cb13495990c9a7ea7c9acdaca4dfdeb7997b9f7c77e77ac718404cf44eac08ae1cd5fcb');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;


--
-- Definition of table `registration`
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE `registration` (
  `attendeeid` int(10) unsigned NOT NULL,
  `sessionid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`attendeeid`,`sessionid`),
  KEY `FK_registration_2` (`sessionid`),
  CONSTRAINT `FK_registration_1` FOREIGN KEY (`attendeeid`) REFERENCES `attendee` (`id`),
  CONSTRAINT `FK_registration_2` FOREIGN KEY (`sessionid`) REFERENCES `session` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

/*!40000 ALTER TABLE `registration` DISABLE KEYS */;
INSERT INTO `registration` (`attendeeid`,`sessionid`) VALUES 
 (24,1),
 (26,1),
 (27,1),
 (28,1),
 (29,1),
 (32,1),
 (35,1),
 (40,1),
 (41,1),
 (11,2),
 (12,2),
 (15,2),
 (25,2),
 (30,2),
 (31,2),
 (33,2),
 (34,2),
 (37,2),
 (38,2),
 (39,2),
 (47,2),
 (49,2),
 (1,3),
 (2,3),
 (5,3),
 (7,3),
 (10,3),
 (14,3),
 (16,3),
 (17,3),
 (18,3),
 (21,3),
 (22,3),
 (42,3),
 (44,3),
 (45,3),
 (46,3),
 (50,3),
 (3,4),
 (4,4),
 (6,4),
 (8,4),
 (9,4),
 (13,4),
 (19,4),
 (20,4),
 (23,4),
 (36,4),
 (43,4),
 (48,4);
/*!40000 ALTER TABLE `registration` ENABLE KEYS */;


--
-- Definition of table `session`
--

DROP TABLE IF EXISTS `session`;
CREATE TABLE `session` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session`
--

/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` (`id`,`description`) VALUES 
 (1,'Session 1 (TR 9:15 am - 10:45 am)'),
 (2,'Session 2 (TR 12:45 pm - 2:15 pm)'),
 (3,'Session 3 (MWF 11:15 am - 12:15 pm)'),
 (4,'Session 4 (MWF 1:45 pm - 2:45 pm)');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;


--
-- Definition of table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
CREATE TABLE `userrole` (
  `username` varchar(45) NOT NULL,
  `rolename` varchar(45) NOT NULL,
  PRIMARY KEY (`username`,`rolename`),
  CONSTRAINT `FK_userrole_1` FOREIGN KEY (`username`) REFERENCES `login` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userrole`
--

/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` (`username`,`rolename`) VALUES 
 ('dbuser','user');
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
